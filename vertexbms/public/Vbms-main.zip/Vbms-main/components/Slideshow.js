'use client';

import React, { useState, useRef, useEffect } from 'react';
import ProfileSection from './Step';

const Slideshow = () => {
    const [isDragging, setIsDragging] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(0);
    const containerRef = useRef(null);
    const intervalRef = useRef(null);
    const observerRef = useRef(null);
    const timeoutRef = useRef(null);

    // Container styles
    const containerStyles = {
        display: 'flex',
        overflowX: 'auto',
        scrollSnapType: 'x mandatory',
        scrollBehavior: 'smooth',
        width: '100%',
        gap: '80px',
        cursor: isDragging ? 'grabbing' : 'grab',
        scrollbarWidth: 'none',
        msOverflowStyle: 'none',
        padding: '0 40px',
    };

    // Auto-scroll functionality
    const startAutoScroll = () => {
        intervalRef.current = setInterval(() => {
            setCurrentIndex(prev => {
                const newIndex = (prev + 1) % 3; // Assuming 3 slides
                scrollToSlide(newIndex);
                return newIndex;
            });
        }, 3000); // Changed to 3 seconds for better UX
    };

    const scrollToSlide = (index) => {
        if (containerRef.current) {
            const container = containerRef.current;
            const slide = container.children[index];
            container.scrollTo({
                left: slide.offsetLeft - 40, // Adjust for padding
                behavior: 'smooth'
            });
        }
    };

    // Intersection Observer to detect when component is visible
    useEffect(() => {
        observerRef.current = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    startAutoScroll();
                } else {
                    clearInterval(intervalRef.current);
                }
            });
        });

        if (containerRef.current) {
            observerRef.current.observe(containerRef.current);
        }

        return () => {
            observerRef.current?.disconnect();
            clearInterval(intervalRef.current);
        };
    }, []);

    // Drag handlers with auto-scroll control
    const handleMouseDown = (e) => {
        setIsDragging(true);
        clearInterval(intervalRef.current);
        setStartX(e.pageX - containerRef.current.offsetLeft);
        setScrollLeft(containerRef.current.scrollLeft);
    };

    const handleInteractionEnd = () => {
        setIsDragging(false);
        // Restart auto-scroll after 5 seconds of inactivity
        clearTimeout(timeoutRef.current);
        timeoutRef.current = setTimeout(startAutoScroll, 5000);
    };

    // Prevent memory leaks
    useEffect(() => {
        return () => {
            clearInterval(intervalRef.current);
            clearTimeout(timeoutRef.current);
            observerRef.current?.disconnect();
        };
    }, []);

    return (
        <div
            ref={containerRef}
            style={containerStyles}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleInteractionEnd}
            onMouseLeave={handleInteractionEnd}
        >
            {/* Slides */}
            <div style={{ flex: '0 0 70%', scrollSnapAlign: 'start' }}>
                <ProfileSection {...props1} />
            </div>
            <div style={{ flex: '0 0 70%', scrollSnapAlign: 'start' }}>
                <ProfileSection {...props2} />
            </div>
            <div style={{ flex: '0 0 70%', scrollSnapAlign: 'start' }}>
                <ProfileSection {...props3} />
            </div>
        </div>
    );
};

export default Slideshow;